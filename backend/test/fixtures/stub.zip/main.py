def handler(event, ctx):
    return {"ok": True}
